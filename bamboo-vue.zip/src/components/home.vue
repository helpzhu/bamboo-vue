<template>
	<div class="div-container">
		<el-container>
			<el-aside>
				<el-menu
					@open="handleOpen"
					@close="handleClose"
					theme="dark" model="vertical">
					<el-submenu index="1">
						<template slot="title">
							<i class="el-icon-location"></i>
							<span>导航一</span>
						</template>
						<el-menu-item index="1-1">选项1</el-menu-item>
						<el-menu-item index="1-2">选项2</el-menu-item>
						<el-menu-item index="1-3">选项3</el-menu-item>
					</el-submenu>
					<el-submenu index="2">
						<template slot="title">
							<i class="el-icon-location"></i>
							<span>导航一</span>
						</template>
						<el-menu-item index="1-1">选项1</el-menu-item>
						<el-menu-item index="1-2">选项2</el-menu-item>
						<el-menu-item index="1-3">选项3</el-menu-item>
					</el-submenu>
				</el-menu>
			</el-aside>

			<el-container>
				<el-header style="text-align: right; font-size: 12px">
					<el-dropdown>
						<i class="el-icon-setting" style="margin-right: 15px"></i>
						<el-dropdown-menu slot="dropdown">
							<el-dropdown-item>查看</el-dropdown-item>
							<el-dropdown-item>新增</el-dropdown-item>
							<el-dropdown-item>删除</el-dropdown-item>
						</el-dropdown-menu>
					</el-dropdown>
					<span>王小虎</span>
				</el-header>

				<el-main>
					<!-- <el-table :data="tableData">
						<el-table-column prop="date" label="日期" width="140">
						</el-table-column>
						<el-table-column prop="name" label="姓名" width="120">
						</el-table-column>
						<el-table-column prop="address" label="地址">
						</el-table-column>
					</el-table> -->
				</el-main>
			</el-container>
		</el-container>
	</div>
</template>

<script>
	export default {
		name: 'home',
		data() {
			const item = {
				date: '2016-05-02',
				name: '王小虎',
				address: '上海市普陀区金沙江路 1518 弄'
			};
			return {
				isCollapse: true,
				tableData: Array(5).fill(item),
				menus: [{
						id: 1,
						text: '处理中心',
						icon: 'el-icon-goods'
					},
					{
						id: 2,
						text: '我的工作台',
						icon: 'el-icon-setting',
						children: [{
							id: 21,
							text: '选项一'
						}, {
							id: 22,
							text: '选项二'
						}, {
							id: 23,
							text: '选项三'
						}]
					}, {
						id: 3,
						text: '消息中心',
						icon: 'el-icon-phone'
					}, {
						id: 4,
						text: '订单管理',
						icon: 'el-icon-news'
					}
				]
			};
		},
		components: {
		},
		created() {
			let info = {
				id: 1,
				icon: '',
				name: 'test1',
				children: {
					id: 2,
					icon: '',
					name: 'test11'
				}
			}
			this.menus.push(info);
		},
		methods: {
			handleOpen(key, keyPath) {
				//console.log(key, keyPath);
			},
			handleClose(key, keyPath) {
				//console.log(key, keyPath);
			}
		}
	}
</script>

<style>
	.el-header {
		background-color: #fafafa;
		color: #333;
		line-height: 60px;
	}

	.el-aside {
		-webkit-transition: width .28s;
		transition: width .28s;
		width: 210px !important;
		/* background-color: #304156; */
		height: 100%;
		position: fixed;
		font-size: 0;
		top: 0;
		bottom: 0;
		left: 0;
		z-index: 1001;
		overflow: hidden;
	}

	.el-menu,
	.el-menu-item {
		height: 60px !important;
		line-height: 60px;
		background-color: #30415;
	}
</style>
