let contextPath = '/';

export const httpApi = {
    '': contextPath + "/user/getAllUser",
}

